#!/usr/bin/env python
# coding: utf-8

from selectmenu.core import SelectMenu

__author__ = "Hayato Tominaga"
__version__ = "1.0.0b2"
__all__ = ["SelectMenu"]
